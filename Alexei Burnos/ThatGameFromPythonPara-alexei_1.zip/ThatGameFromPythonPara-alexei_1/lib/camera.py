from lib.constants import CAMERA_X, CAMERA_Y


class Camera:
    def __init__(self):
        self.position = [CAMERA_X, CAMERA_Y]
